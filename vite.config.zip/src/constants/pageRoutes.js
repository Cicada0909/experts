const files = "/files";

const filesRoutes = {
    files: files,
};

const profile = "/profile"

const profileRoutes = {
    profile: profile,
};

export const pageRoutes = {
    filesRoutes,
    profileRoutes,
};